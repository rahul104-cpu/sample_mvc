package com.example.service;

import com.example.model.Employee;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
    public Employee getEmployeeById(int id) {
        return new Employee(id, "John Doe", "Engineering", 75000);
    }
}
